﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string connectionString =
            @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Производство.mdb;";

        private readonly string _role;

        public Form1() : this("user") { }

        public Form1(string role)
        {
            InitializeComponent();
            _role = role;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "База данных «Производство»";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ApplyAccessLevel();
        }

       
        private void ApplyAccessLevel()
        {
            bool isAdmin = !string.IsNullOrWhiteSpace(_role) &&
                           _role.Equals("admin", StringComparison.OrdinalIgnoreCase);

            foreach (Control ctl in Controls)
            {
                if (ctl is TabControl tabs)
                {
                    foreach (TabPage page in tabs.TabPages)
                    {
                        foreach (Control inner in page.Controls)
                        {
                            if (inner is DataGridView grid)
                            {
                                grid.ReadOnly = !isAdmin;            
                                grid.AllowUserToAddRows = isAdmin;
                                grid.AllowUserToDeleteRows = isAdmin;
                                grid.EditMode = isAdmin
                                    ? DataGridViewEditMode.EditOnKeystrokeOrF2
                                    : DataGridViewEditMode.EditProgrammatically;
                            }

                           
                            if (inner is Button btn && btn.Name.StartsWith("buttonSave"))
                                btn.Visible = isAdmin;
                        }
                    }
                }
            }
        }

        
        private void LoadData(string sql, DataGridView grid)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    grid.DataSource = dt;
                    grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

       
        private void SaveTable(string tableName, DataGridView grid)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    string select = $"SELECT * FROM [{tableName}]";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(select, conn);
                    OleDbCommandBuilder builder = new OleDbCommandBuilder(adapter);

                    DataTable dt = (DataTable)grid.DataSource;
                    adapter.Update(dt);

                    MessageBox.Show($"Изменения в таблице «{tableName}» сохранены.",
                        "Сохранено", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

      
        private void button1_Click(object sender, EventArgs e) =>
            LoadData("SELECT * FROM [Изделия];", dataGridView1);

        private void button2_Click(object sender, EventArgs e)
        {
            string sql = @"
                SELECT p.ProductName
                FROM [Изделия] AS p
                WHERE p.ProductID NOT IN (
                    SELECT pr.ProductID
                    FROM [Производство на предприятии] AS pr
                    WHERE pr.[Year] = 1990
                );";
            LoadData(sql, dataGridView2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sql = @"
                SELECT p.ProductName,
                       SUM(s.Quantity) AS Quantity
                FROM ([Изделия] AS p
                      INNER JOIN [Спецификация] AS s ON p.ProductID = s.ProductID)
                      INNER JOIN [Материалы] AS m ON s.MaterialID = m.MaterialID
                WHERE m.[Type] = 'цветной металл'
                GROUP BY p.ProductName
                HAVING SUM(s.Quantity) = (
                    SELECT MAX(TotalSum)
                    FROM (
                        SELECT SUM(s2.Quantity) AS TotalSum
                        FROM ([Изделия] AS p2
                              INNER JOIN [Спецификация] AS s2 ON p2.ProductID = s2.ProductID)
                              INNER JOIN [Материалы] AS m2 ON s2.MaterialID = m2.MaterialID
                        WHERE m2.[Type] = 'цветной металл'
                        GROUP BY p2.ProductName
                    ) AS totals
                );";
            LoadData(sql, dataGridView3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string sql = @"
                SELECT DISTINCT p.ProductName
                FROM [Изделия] AS p
                WHERE p.ProductID IN (
                    SELECT q2000.ProductID
                    FROM (
                        SELECT pr.ProductID,
                               SUM(s.Quantity * m.UnitPrice * pr.OutputAmount) AS Cost1999
                        FROM (([Производство на предприятии] AS pr
                               INNER JOIN [Спецификация] AS s ON pr.ProductID = s.ProductID)
                               INNER JOIN [Материалы] AS m ON s.MaterialID = m.MaterialID)
                        WHERE pr.[Year] = 1999
                        GROUP BY pr.ProductID
                    ) AS q1999
                    INNER JOIN (
                        SELECT pr.ProductID,
                               SUM(s.Quantity * m.UnitPrice * pr.OutputAmount) AS Cost2000
                        FROM (([Производство на предприятии] AS pr
                               INNER JOIN [Спецификация] AS s ON pr.ProductID = s.ProductID)
                               INNER JOIN [Материалы] AS m ON s.MaterialID = m.MaterialID)
                        WHERE pr.[Year] = 2000
                        GROUP BY pr.ProductID
                    ) AS q2000
                    ON q1999.ProductID = q2000.ProductID
                    WHERE q2000.Cost2000 < q1999.Cost1999
                );";
            LoadData(sql, dataGridView4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string sql = @"
                SELECT m.MaterialName,
                       SUM(s.Quantity * p.OutputAmount) / 12 AS AvgMonthlyConsumption
                FROM (([Материалы] AS m
                       INNER JOIN [Спецификация] AS s ON m.MaterialID = s.MaterialID)
                       INNER JOIN [Производство на предприятии] AS p ON s.ProductID = p.ProductID)
                WHERE m.MaterialName='лапша' AND p.[Year]=2000
                GROUP BY m.MaterialName;";
            LoadData(sql, dataGridView5);
        }

        private void button6_Click(object sender, EventArgs e) =>
            LoadData("SELECT * FROM [Материалы];", dataGridView6);

        private void button7_Click(object sender, EventArgs e) =>
            LoadData("SELECT * FROM [Спецификация];", dataGridView7);

        private void button8_Click(object sender, EventArgs e) =>
            LoadData("SELECT * FROM [Предприятия];", dataGridView8);

        private void button9_Click(object sender, EventArgs e) =>
            LoadData("SELECT * FROM [Производство на предприятии];", dataGridView9);

       
        private void buttonSave1_Click(object sender, EventArgs e) =>
            SaveTable("Изделия", dataGridView1);

        private void buttonSave6_Click(object sender, EventArgs e) =>
            SaveTable("Материалы", dataGridView6);

        private void buttonSave7_Click(object sender, EventArgs e) =>
            SaveTable("Спецификация", dataGridView7);

        private void buttonSave8_Click(object sender, EventArgs e) =>
            SaveTable("Предприятия", dataGridView8);

        private void buttonSave9_Click(object sender, EventArgs e) =>
            SaveTable("Производство на предприятии", dataGridView9);
    }
}